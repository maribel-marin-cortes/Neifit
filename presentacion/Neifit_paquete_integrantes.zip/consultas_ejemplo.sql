-- Ejemplos para el esquema diseñado. Consultas de solo lectura.
-- Requieren las tablas instaladas y registros persistidos.

-- Productos con pocas unidades.
select name, stock from public.products
where is_active = true and stock <= 5 order by stock;

-- Cotizaciones pendientes e importe de referencia.
select q.quote_number, q.customer_name, q.created_at,
  coalesce(sum(i.quantity * i.reference_price), 0) as total_referencia
from public.quotes q
left join public.quote_items i on i.quote_id = q.id
where q.status = 'pendiente'
group by q.id, q.quote_number, q.customer_name, q.created_at
order by q.created_at;

-- Pedidos pendientes de entrega, con o sin mensajero asignado.
select o.order_number, o.order_status,
  coalesce(p.full_name, 'Sin asignar') as mensajero
from public.orders o
left join public.profiles p on p.id = o.assigned_delivery_user_id
where o.order_status not in ('entregado','cancelado')
order by o.created_at;

-- Productos con más unidades en pedidos no cancelados y pago aprobado.
select p.name, sum(i.quantity) as unidades
from public.order_items i
join public.orders o on o.id = i.order_id
join public.products p on p.id = i.product_id
where o.payment_status = 'aprobado' and o.order_status <> 'cancelado'
group by p.id, p.name order by unidades desc;
